package com.nexplayer.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class Video(val name:String, val uri:Uri, val duration:Long)

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var root: LinearLayout
    private lateinit var items: LinearLayout
    private val videos = mutableListOf<Video>()
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if(it) loadVideos() }
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { play(it, "Selected video") }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        home()
        val p = if(Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if(ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED) loadVideos() else permission.launch(p)
    }
    private fun home() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,12); setBackgroundColor(0xFF090B12.toInt()) }
        val header = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text="NEXPLAYER"; textSize=25f; letterSpacing=.12f; setTextColor(-1); typeface=android.graphics.Typeface.DEFAULT_BOLD }
        val open = Button(this).apply { text="OPEN"; setOnClickListener { picker.launch(arrayOf("video/*")) } }
        header.addView(brand, LinearLayout.LayoutParams(0,120,1f)); header.addView(open)
        root.addView(header)
        root.addView(TextView(this).apply { text="YOUR MEDIA, YOUR WAY"; textSize=11f; setTextColor(0xFF9CA3B8.toInt()) })
        root.addView(TextView(this).apply { text="Your video library"; textSize=19f; setTextColor(-1); setPadding(0,24,0,12) })
        val scroll=ScrollView(this); items=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; scroll.addView(items)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(TextView(this).apply { text="NexPlayer • Premium local video player"; gravity=Gravity.CENTER; setTextColor(0xFF7F879A.toInt()); setPadding(0,16,0,8) })
        setContentView(root)
    }
    private fun loadVideos() {
        videos.clear()
        val collection=MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection=arrayOf(MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.DURATION)
        contentResolver.query(collection,projection,null,null,"${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val id=c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val name=c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dur=c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while(c.moveToNext()) videos.add(Video(c.getString(name) ?: "Video",ContentUris.withAppendedId(collection,c.getLong(id)),c.getLong(dur)))
        }
        items.removeAllViews()
        if(videos.isEmpty()) {
            items.addView(TextView(this).apply { text="No videos found. Tap OPEN to choose a video."; textSize=15f; gravity=Gravity.CENTER; setTextColor(0xFFADB4C5.toInt()); setPadding(12,70,12,70) })
        } else videos.forEach { v ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(14,16,14,16); setBackgroundColor(0xFF171C2B.toInt()) }
            row.addView(TextView(this).apply { text="▶"; textSize=22f; setTextColor(0xFFB79BFF.toInt()); gravity=Gravity.CENTER },LinearLayout.LayoutParams(48,48))
            row.addView(TextView(this).apply { text=v.name+"\n"+(v.duration/60000)+" min"; textSize=14f; setTextColor(-1); setPadding(12,0,0,0) },LinearLayout.LayoutParams(0,-2,1f))
            row.setOnClickListener { play(v.uri,v.name) }
            val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=10; items.addView(row,lp)
        }
    }
    private fun play(uri:Uri,title:String) {
        val screen=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,10,10,10); setBackgroundColor(0xFF090B12.toInt()) }
        val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        top.addView(Button(this).apply { text="‹ Back"; setOnClickListener { player.pause(); home(); loadVideos() } })
        top.addView(TextView(this).apply { text=title; setTextColor(-1); textSize=14f; setPadding(10,0,0,0); maxLines=1 })
        screen.addView(top)
        val pv=PlayerView(this).apply { player=this@MainActivity.player; useController=true }
        screen.addView(pv,LinearLayout.LayoutParams(-1,0,1f))
        val controls=LinearLayout(this).apply { gravity=Gravity.CENTER }
        controls.addView(Button(this).apply { text="Speed"; setOnClickListener {
            val speeds=arrayOf("0.5x","0.75x","1x","1.25x","1.5x","2x","3x","4x")
            android.app.AlertDialog.Builder(this@MainActivity).setTitle("Playback speed").setItems(speeds) { _,i -> player.setPlaybackSpeed(speeds[i].removeSuffix("x").toFloat()) }.show()
        }})
        screen.addView(controls)
        setContentView(screen)
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play()
    }
    override fun onStop(){ super.onStop(); player.pause() }
    override fun onDestroy(){ player.release(); super.onDestroy() }
}
